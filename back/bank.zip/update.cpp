#include"game.h"


void MAINMenu :: update(int x,int y){

    this->destination.x=x-this->destination.w/2;
    this->destination.y=y-this->destination.h/2;



}
